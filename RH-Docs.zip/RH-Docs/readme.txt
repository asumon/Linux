%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

This is the Red Hat Linux documentation CD-ROM.

In this directory, you will find one HTML file for each supported language.
Each file is named:

                               index-??.html

Where "??" is the language code.  Please select the appropriate file, and
open it with a web browser.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
